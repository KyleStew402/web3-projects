export interface ChartData {
  price: number
  y_position: number
  time: number
}
