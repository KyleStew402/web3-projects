import { FC } from 'react'
import './style.scss'

interface SampleProps {
  // eslint-disable-next-line react/no-unused-prop-types
  text: string
}

const SampleConponent: FC<SampleProps> = prop => (
  // eslint-disable-next-line react/destructuring-assignment
  <span className="sample">{prop.text}</span>
)

export default SampleConponent
