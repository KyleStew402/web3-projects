// this is a component file
import HeaderComponent from './components'

const Header = () => {
  return <HeaderComponent />
}

export default Header
