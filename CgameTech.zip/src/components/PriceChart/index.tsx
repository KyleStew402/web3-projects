/* eslint-disable react/require-default-props */
import React, { useState, useEffect } from 'react'
import { AreaChart, Area, YAxis, ResponsiveContainer } from 'recharts'
import { ChartData } from '../../types'
import './pricechart.scss'

interface PageProps {
  data: ChartData[]
  width?: string
  height?: string
}

const fakeData = [
  { name: 'A', x: 12, y: 23, z: 122 },
  { name: 'B', x: 22, y: 3, z: 73 },
  { name: 'C', x: 13, y: 15, z: 32 },
  { name: 'D', x: 42, y: 35, z: 23 },
  { name: 'E', x: 51, y: 45, z: 20 },
  { name: 'F', x: 16, y: 25, z: 29 },
  { name: 'G', x: 17, y: 17, z: 61 },
  { name: 'H', x: 81, y: 32, z: 45 },
  { name: 'I', x: 19, y: 43, z: 93 },
]

export const PriceChart = ({ data, width, height }: PageProps) => {
  const [isIncrease, setIsIncrease] = useState<boolean>(true)
  const [min, setMin] = useState(0)
  const [max, setMax] = useState(1)
  const theme = 'dark'

  useEffect(() => {
    setIsIncrease(data[0].price < data[data.length - 1].price)
    const temp = []
    for (let i = 0; i < data.length; i += 1) {
      temp.push(data[i].y_position)
    }
    setMin(Math.min(...temp))
    setMax(Math.max(...temp))
  }, [data])

  return (
    <div
      className="chart-body"
      style={{
        width: `${width || 'auto'}px`,
        height: `${height || 'auto'}px`,
      }}
    >
      {data.length > 1 ? (
        <ResponsiveContainer>
          <AreaChart
            data={data}
            margin={{
              top: 0,
              right: 10,
              left: 0,
              bottom: 10,
            }}
          >
            <defs>
              <linearGradient id="colorUvInc" x1="0" y1="0" x2="0" y2="1">
                <stop offset="60.43%" stopColor="#00be4c" stopOpacity={0.2} />
                <stop offset="100%" stopColor="#00be4c" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorUvDec" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="60.43%"
                  stopColor={theme === 'dark' ? '#BE0000' : '#FF2222'}
                  stopOpacity={0.2}
                />
                <stop
                  offset="100%"
                  stopColor={theme === 'dark' ? '#BE0000' : '#FF2222'}
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>
            <YAxis domain={[min, max]} hide />
            <Area
              type="monotone"
              dataKey="y_position"
              isAnimationActive={false}
              stroke={isIncrease ? '#00be4c' : '#BE0000'}
              strokeWidth={1}
              fill={isIncrease ? 'url(#colorUvInc)' : 'url(#colorUvDec)'}
            />
          </AreaChart>
        </ResponsiveContainer>
      ) : (
        <AreaChart width={100} height={53} data={fakeData}>
          <defs>
            <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#129a74" stopOpacity={0.1} />
              <stop offset="95%" stopColor="#0c0c0c" stopOpacity={0.1} />
            </linearGradient>
          </defs>
          <Area
            type="monotone"
            dataKey="y"
            stroke="green"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorUv)"
          />
        </AreaChart>
      )}
    </div>
  )
}
