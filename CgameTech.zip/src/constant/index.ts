export const CHAIN_ID = 43114

export const DefaultNetwork = Number(CHAIN_ID)

export const supportedChainIds = [43114]

export const networkLists = [43114]

export const networkInfo: any = {
  43113: {
    label: 'Avalanche Fuji Testnet',
    rpcUrl: 'https://api.avax-test.network/ext/bc/C/rpc',
    nativeCurrency: 'AVAX',
    explorer: 'https://cchain.explorer.avax-test.network',
  },
  43114: {
    label: 'Avalanche Network',
    rpcUrl: 'https://api.avax.network/ext/bc/C/rpc',
    nativeCurrency: 'AVAX',
    explorer: 'https://snowtrace.io/',
  },
}
