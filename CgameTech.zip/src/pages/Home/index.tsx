/* eslint-disable no-nested-ternary */
/* eslint-disable @typescript-eslint/no-unused-vars */
// this is a component file
import { SetStateAction, useEffect, useState } from 'react'
import { useWeb3React } from '@web3-react/core'
import { Link } from 'react-router-dom'
import { Swiper, SwiperSlide } from 'swiper/react/swiper-react'
import { EffectCoverflow, Navigation, Pagination, Autoplay } from 'swiper'
import { AreaChart, Area } from 'recharts'
import { toast } from 'react-toastify'
import { Contract } from '@ethersproject/contracts'
import { PriceChart } from '../../components/PriceChart'
import { getChartData } from '../../utils/fetch'
import { ChartData } from '../../types'
import NFT_INFO from '../../artifacts/contracts/GameNFT_1.sol/GAMENFT.json'

import 'swiper/swiper-bundle.min.css'
import 'swiper/swiper.min.css'
import 'swiper/modules/effect-fade/effect-fade'
import 'swiper/modules/navigation/navigation'
import 'swiper/modules/pagination/pagination'
import 'swiper/swiper.scss'
import './style.scss'

interface CoinInfo {
  chartTemp: ChartData[]
  percent: number
}

const initialCoinData = {
  chartTemp: [
    {
      price: 0,
      y_position: 0,
      time: 0,
    },
  ],
  percent: 0,
}

const coverEffectSetting = {
  rotate: 0,
  stretch: 50,
  depth: 200,
  modifier: 1,
  slideShadows: true,
}

const breakPointsSetting = {
  768: {
    slidesPerView: 3,
  },
  1200: {
    slidesPerView: 3,
    coverflowEffect: {
      stretch: 100,
      depth: 200,
      modifier: 1,
    },
  },
  1400: {
    slidesPerView: 3,
    coverflowEffect: {
      stretch: 130,
      depth: 150,
      modifier: 1,
    },
  },
}

const Home = () => {
  const { account, library, active, activate } = useWeb3React()
  const [btcInfo, setBtcInfo] = useState<CoinInfo>(initialCoinData)
  const [btcPrice, setBtcPrice] = useState<number>(42471.09)
  const [ethInfo, setEthInfo] = useState<CoinInfo>(initialCoinData)
  const [ethPrice, setEthPrice] = useState<number>(3152.16)
  const [bnbInfo, setBnbInfo] = useState<CoinInfo>(initialCoinData)
  const [bnbPrice, setBnbPrice] = useState<number>(70.49)
  const [usdtInfo, setUsdtInfo] = useState<CoinInfo>(initialCoinData)
  const [usdtPrice, setUsdtPrice] = useState<number>(1)
  const [loading, setLoading] = useState<boolean>(false)
  const [tokenIds, setTokenIds] = useState<number[]>([])
  const [selectedTokenId, setSelectedTokenId] = useState<number>(0)

  const getTokenIds = async () => {
    try {
      if (account) {
        const nftContract = new Contract(
          process.env.REACT_APP_NFT_ADDRESS || '',
          NFT_INFO.abi,
          library.getSigner(),
        )
        const tokenIdsTemp = await nftContract.tokensOfOwner(account)
        const newTemp: any[] = []
        tokenIdsTemp.map((item: any) => newTemp.push(Number(item)))
        setTokenIds(newTemp)
      }
    } catch (err) {
      console.log(err)
    }
  }

  const getBtcData = async () => {
    setLoading(true)
    const btcInfoTemp = await getChartData('bitcoin')
    setBtcInfo(btcInfoTemp)
    setBtcPrice(
      btcInfoTemp.chartTemp[btcInfoTemp.chartTemp.length - 1].y_position,
    )
    const ethInfoTemp = await getChartData('ethereum')
    setEthInfo(ethInfoTemp)
    setEthPrice(
      ethInfoTemp.chartTemp[ethInfoTemp.chartTemp.length - 1].y_position,
    )
    const bnbInfoTemp = await getChartData('avalanche-2')
    setBnbInfo(bnbInfoTemp)
    setBnbPrice(
      bnbInfoTemp.chartTemp[bnbInfoTemp.chartTemp.length - 1].y_position,
    )
    const usdtInfoTemp = await getChartData('tether')
    setUsdtInfo(usdtInfoTemp)
    setUsdtPrice(
      usdtInfoTemp.chartTemp[usdtInfoTemp.chartTemp.length - 1].y_position,
    )
    setLoading(false)
  }

  useEffect(() => {
    setInterval(() => {
      getBtcData()
      getTokenIds()
    }, 10000)
  }, [])

  useEffect(() => {
    getTokenIds()
  }, [account])

  const comingSoon = () => {
    toast.info('Coming soon!')
  }

  return (
    <>
      <div className="slider-container">
        <Swiper
          modules={[EffectCoverflow, Navigation, Pagination, Autoplay]}
          spaceBetween={50}
          slidesPerView={1}
          effect="coverflow"
          centeredSlides
          autoplay={{
            delay: 2500,
          }}
          grabCursor
          coverflowEffect={coverEffectSetting}
          breakpoints={breakPointsSetting}
          navigation
          pagination={{
            clickable: true,
          }}
          loop
        >
          <SwiperSlide>
            <img src="images/4.png" className="slider-img" alt="sliderImage" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="images/1.png" className="slider-img" alt="sliderImage" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="images/2.png" className="slider-img" alt="sliderImage" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="images/3.png" className="slider-img" alt="sliderImage" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="images/5.png" className="slider-img" alt="sliderImage" />
          </SwiperSlide>
        </Swiper>
      </div>
      <div className="container">
        <div className="flex flex-wrap w-full">
          <div className="xl:w-6/12 w-full">
            <div
              className="flex mb-12 items-center justify-content-between w-full"
              data-aos="fade-up"
              data-aos-duration="1000"
            >
              <div className="category">TokenID</div>
              <div className="value">
                {account && selectedTokenId !== 0 ? `#${selectedTokenId}` : '-'}
              </div>
            </div>
            <div
              className="flex mb-12 items-center justify-content-between w-full"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="100"
            >
              <div className="category">Crypto</div>
              <div className="value">{account ? '-' : '-'}</div>
            </div>
            <div
              className="flex mb-12 items-center justify-content-between w-full"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="200"
            >
              <div className="category">Category</div>
              <div className="value">{account ? '-' : '-'}</div>
            </div>
            <div
              className="flex mb-12 items-center justify-content-between w-full"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="300"
            >
              <div className="category">Status</div>
              <div className="value">
                {account
                  ? selectedTokenId !== 0
                    ? 'Ready to stake'
                    : '-'
                  : '-'}
              </div>
            </div>
            <div
              className="flex mb-12 items-center justify-content-between w-full"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="400"
            >
              <div className="category">Reward $CARD</div>
              <div className="value">{account ? '-' : '-'}</div>
            </div>
          </div>
          <div className="btn-group xl:w-6/12 w-full">
            <button
              type="button"
              className="long"
              data-aos="fade-up"
              data-aos-duration="1000"
              onClick={comingSoon}
            >
              Long
            </button>
            <button
              type="button"
              className="short"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="100"
              onClick={comingSoon}
            >
              Short
            </button>
            <button
              type="button"
              className="stake"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="200"
              onClick={comingSoon}
            >
              Stake/Unstake
            </button>
            <button
              type="button"
              className="stake"
              data-aos="fade-up"
              data-aos-duration="1000"
              data-aos-delay="300"
              onClick={comingSoon}
            >
              Claim reward
            </button>
          </div>
        </div>
        <div className="flex justify-between flex-wrap items-center max-w-screen-xl md:mx-48 mx-auto my-28">
          <div
            className="coin-trend-item"
            data-aos="fade-right"
            data-aos-duration="1000"
          >
            <div className="flex justify-between card-header">
              <div className="flex items-center">
                <img
                  src="images/bitcoinIcon.png"
                  alt=""
                  className="coin-image"
                />
                <p className="coin-type">BTC</p>
                <span className="coin-name">BITCOIN</span>
              </div>
              <a
                href="https://www.coingecko.com/en/coins/bitcoin"
                target="_blank"
                rel="noreferrer"
              >
                <img src="images/see-more-ic.png" alt="more" />
              </a>
            </div>
            <div className="flex justify-between">
              <div className="flex flex-col mr-3">
                <h1 className="coin-price">
                  ${Number(btcPrice.toFixed(2)).toLocaleString()}
                </h1>
                <p className="coin-percentage">{btcInfo?.percent}%</p>
              </div>
              <div>
                {btcInfo && (
                  <PriceChart
                    data={btcInfo.chartTemp}
                    width="100"
                    height="53"
                  />
                )}
              </div>
            </div>
          </div>
          <div
            className="coin-trend-item"
            data-aos="fade-right"
            data-aos-duration="1000"
          >
            <div className="flex justify-between card-header">
              <div className="flex items-center">
                <img src="images/etherIcon.png" alt="" className="coin-image" />
                <p className="coin-type">ETH</p>
                <span className="coin-name">ETHEREUM</span>
              </div>
              <a
                href="https://www.coingecko.com/en/coins/ethereum"
                target="_blank"
                rel="noreferrer"
              >
                <img src="images/see-more-ic.png" alt="more" />
              </a>
            </div>
            <div className="flex justify-between">
              <div className="flex flex-col mr-3">
                <h1 className="coin-price">
                  ${Number(ethPrice.toFixed(2)).toLocaleString()}
                </h1>
                <p className="coin-percentage">{ethInfo?.percent}%</p>
              </div>
              <div>
                {ethInfo && (
                  <PriceChart
                    data={ethInfo.chartTemp}
                    width="100"
                    height="53"
                  />
                )}
              </div>
            </div>
          </div>
          <div
            className="coin-trend-item"
            data-aos="fade-left"
            data-aos-duration="1000"
          >
            <div className="flex justify-between card-header">
              <div className="flex items-center">
                <img src="images/avaxIcon.png" alt="" className="coin-image" />
                <p className="coin-type">AVAX</p>
                <span className="coin-name">AVALANCHE</span>
              </div>
              <a
                href="https://www.coingecko.com/en/coins/avalanche"
                target="_blank"
                rel="noreferrer"
              >
                <img src="images/see-more-ic.png" alt="more" />
              </a>
            </div>
            <div className="flex justify-between">
              <div className="flex flex-col mr-3">
                <h1 className="coin-price">
                  ${Number(bnbPrice.toFixed(2)).toLocaleString()}
                </h1>
                <p className="coin-percentage">{bnbInfo?.percent}%</p>
              </div>
              <div>
                {bnbInfo && (
                  <PriceChart
                    data={bnbInfo.chartTemp}
                    width="100"
                    height="53"
                  />
                )}
              </div>
            </div>
          </div>
          <div
            className="coin-trend-item"
            data-aos="fade-left"
            data-aos-duration="1000"
          >
            <div className="flex justify-between card-header">
              <div className="flex items-center">
                <img src="images/usdtIcon.png" alt="" className="coin-image" />
                <p className="coin-type">USDT</p>
                <span className="coin-name">TETHER</span>
              </div>
              <a
                href="https://www.coingecko.com/en/coins/tether"
                target="_blank"
                rel="noreferrer"
              >
                <img src="images/see-more-ic.png" alt="more" />
              </a>
            </div>
            <div className="flex justify-between">
              <div className="flex flex-col mr-3">
                <h1 className="coin-price">
                  ${Number(usdtPrice.toFixed(2)).toLocaleString()}
                </h1>
                <p className="coin-percentage">{usdtInfo?.percent}%</p>
              </div>
              <div>
                {usdtInfo && (
                  <PriceChart
                    data={usdtInfo.chartTemp}
                    width="100"
                    height="53"
                  />
                )}
              </div>
            </div>
          </div>
        </div>
        <div
          className="relative overflow-x-auto mb-56"
          data-aos="fade-up"
          data-aos-duration="1000"
        >
          <table className="w-full status-table">
            <thead>
              <tr>
                <th scope="col" className="px-6 py-3">
                  Token ID
                </th>
                <th scope="col" className="px-6 py-3">
                  Crypto
                </th>
                <th scope="col" className="px-6 py-3">
                  Category
                </th>
                <th scope="col" className="px-6 py-3">
                  Status
                </th>
                <th scope="col" className="px-6 py-3">
                  Current rewards
                </th>
              </tr>
            </thead>
            <tbody>
              {account ? (
                tokenIds.length > 0 ? (
                  tokenIds.map((item, index) => (
                    <tr
                      // eslint-disable-next-line react/no-array-index-key
                      key={`token-info-${index}`}
                      onClick={() => setSelectedTokenId(item)}
                    >
                      <td>#{item}</td>
                      <td>-</td>
                      <td>-</td>
                      <td>Ready to stake</td>
                      <td>-</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="font-27">
                      You have no NFTs!
                    </td>
                  </tr>
                )
              ) : (
                <tr>
                  <td colSpan={5} className="font-27">
                    Connect Wallet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}

export default Home
