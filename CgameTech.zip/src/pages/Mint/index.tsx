// this is a component file
import { useEffect, useState } from 'react'
import { Swiper, SwiperSlide } from 'swiper/react/swiper-react'
import { useWeb3React } from '@web3-react/core'
import { Contract } from '@ethersproject/contracts'
import { parseEther } from '@ethersproject/units'
import { EffectCoverflow, Autoplay } from 'swiper'
import { toast } from 'react-toastify'
import NFT_INFO from '../../artifacts/contracts/GameNFT_1.sol/GAMENFT.json'

import 'swiper/swiper-bundle.min.css'
import 'swiper/swiper.min.css'
import 'swiper/modules/effect-fade/effect-fade'
import 'swiper/modules/navigation/navigation'
import 'swiper/modules/pagination/pagination'
import 'swiper/swiper.scss'
import './style.scss'

const coverEffectSetting = {
  rotate: 0,
  stretch: 0,
  depth: 0,
  modifier: 1,
  slideShadows: false,
}

const breakPointsSetting = {
  598: {
    slidesPerView: 5,
  },
  380: {
    slidesPerView: 4,
  },
}

const Mint = () => {
  const [mintNumber, setMintNumber] = useState<number>(1)
  const [totalSupply, setTotalSupply] = useState(0)
  const [loading, setIsLoading] = useState(false)
  const [isOnlyWhitelist, SetIsOnlyWhitelist] = useState(false)
  const [isActive, SetIsActive] = useState(false)
  const { account, library, active, activate } = useWeb3React()
  const increase = () => {
    if (mintNumber < 5) setMintNumber(mintNumber + 1)
  }

  const decrease = () => {
    if (mintNumber > 1) setMintNumber(mintNumber - 1)
  }

  const getTotalSupply = async () => {
    if (active) {
      const nftContract = new Contract(
        process.env.REACT_APP_NFT_ADDRESS || '',
        NFT_INFO.abi,
        library.getSigner(),
      )
      const total = await nftContract.totalSupply()
      setTotalSupply(Number(total))
    } else {
      toast.warning(
        "Wallet is not connected or you won't be able to do anything here",
      )
    }
  }

  const getIsOnlyWhitelist = async () => {
    if (active) {
      const nftContract = new Contract(
        process.env.REACT_APP_NFT_ADDRESS || '',
        NFT_INFO.abi,
        library.getSigner(),
      )
      const response = await nftContract.onlyWhitelisted()
      SetIsOnlyWhitelist(response)
    } else {
      toast.warning(
        "Wallet is not connected or you won't be able to do anything here",
      )
    }
  }

  const getActive = async () => {
    if (active) {
      const nftContract = new Contract(
        process.env.REACT_APP_NFT_ADDRESS || '',
        NFT_INFO.abi,
        library.getSigner(),
      )
      const saleIsActive = await nftContract.saleIsActive()
      SetIsActive(saleIsActive)
    } else {
      toast.warning(
        "Wallet is not connected or you won't be able to do anything here",
      )
    }
  }

  useEffect(() => {
    setTimeout(() => {
      if (active) {
        getTotalSupply()
        getActive()
        getIsOnlyWhitelist()
      }
    }, 1000)
  }, [active])

  const mintNfts = async (number: number) => {
    try {
      if (account) {
        setIsLoading(true)
        const nftContract = new Contract(
          process.env.REACT_APP_NFT_ADDRESS || '',
          NFT_INFO.abi,
          library.getSigner(),
        )
        const nftPrice = await nftContract.nftPrice()
        if (isActive) {
          if (isOnlyWhitelist) {
            const isWhitelist = await nftContract.isWhitelisted(account)
            if (isWhitelist) {
              const res = await nftContract.mint(number, {
                value: nftPrice
                  .mul(number)
                  .mul(75)
                  .div(100),
              })
              res.wait().then(() => {
                setIsLoading(false)
                toast.success('Successfully minted!')
                getTotalSupply()
              })
            } else {
              toast.error('Your address is not in our whitelist.')
              setIsLoading(false)
            }
          } else {
            const res = await nftContract.mint(number, {
              value: nftPrice.mul(number),
            })
            res.wait().then(() => {
              setIsLoading(false)
              toast.success('Successfully minted!')
            })
          }
        } else {
          toast.error('Sale is not active.')
          setIsLoading(false)
        }
      } else {
        toast.error('Wallet is not connected!')
      }
      // eslint-disable-next-line prettier/prettier
    } catch (error: any) {
      console.log(error)
      if (
        error?.data?.message.includes('Exceeded max per wallet for whitelist.')
      )
        toast.error('You exceeded maximum number in your wallet.')
      setIsLoading(false)
    }
  }

  return (
    <>
      <div className="mint-wrap">
        <div
          className="mint-leftside"
          data-aos="fade-up"
          data-aos-duration="2000"
        >
          <p
            className="mint-description"
            data-aos="fade-up"
            data-aos-duration="2000"
          >
            <span>Mint</span> unique NFTs and trade them in short or long
            position to increase your reward.
          </p>
          <div
            className="flex mb-12 mx-auto justify-center"
            data-aos="fade-up"
            data-aos-duration="2000"
            data-aos-delay="200"
          >
            <div className="mint-number-wrap">
              <span>Maximum 5</span>
              <input
                type="number"
                className="mint-number"
                value={mintNumber}
                min={1}
                max={5}
                onChange={(e: any) => setMintNumber(e.target.value)}
              />
            </div>
            <div className="flex items-center">
              <button
                type="button"
                className="dec-btn"
                onClick={() => decrease()}
              >
                -
              </button>
              <button
                type="button"
                className="inc-btn"
                onClick={() => increase()}
              >
                +
              </button>
            </div>
          </div>
          <div
            className="flex items-center justify-center flex-wrap"
            data-aos="fade-up"
            data-aos-duration="2000"
            data-aos-delay="400"
          >
            <div className="flex items-center">
              <img
                src="images/Rocket.png"
                alt="rocket"
                className="sm:mr-16 mr-0"
              />
              <p className="whitespace-nowrap">
                Minted: {`${totalSupply}`}/3500
              </p>
            </div>
            <button
              type="button"
              className="mintBtn"
              disabled={loading}
              onClick={() => mintNfts(mintNumber)}
            >
              {loading ? (
                <div className="flex items-center text-md">
                  <div className="loader"></div>
                  <span>Waiting...</span>
                </div>
              ) : (
                'Mint'
              )}
            </button>
          </div>
          <p className="2xl:mt-20 mt-8 text-center 2xl:mb-12 mb-8">
            Available in Crypto Game
          </p>
          <div>
            <Swiper
              modules={[EffectCoverflow, Autoplay]}
              slidesPerView={3}
              spaceBetween={10}
              effect="coverflow"
              autoplay={{
                delay: 2500,
              }}
              centeredSlides
              centerInsufficientSlides={false}
              coverflowEffect={coverEffectSetting}
              breakpoints={breakPointsSetting}
              grabCursor
              loop
            >
              <SwiperSlide>
                <img
                  src="images/bitcoin-(btc).png"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="images/ethereum-classic-(etc).svg"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="images/enjin-coin-(enj).svg"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="images/litecoin(ltc).svg"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="images/solana-(sol).svg"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="images/trontron-(trx).svg"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
              <SwiperSlide>
                <img
                  src="images/binance-coin-(bnb).png"
                  className="logoImage"
                  alt="logoImage"
                />
              </SwiperSlide>
            </Swiper>
          </div>
        </div>
        <div
          className="mint-rightside"
          data-aos="fade-left"
          data-aos-duration="2000"
        >
          <img src="images/gif_Cards.gif" alt="Goldcard" />
        </div>
      </div>
    </>
  )
}

export default Mint
