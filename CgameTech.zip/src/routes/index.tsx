import { useEffect } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AOS from 'aos'
import 'aos/dist/aos.css'
import Home from '../pages/Home'
import Mint from '../pages/Mint'
import Header from '../components/Header'

const Router = () => {
  useEffect(() => {
    AOS.init({
      once: true,
    })
    AOS.refresh()
  })

  return (
    <BrowserRouter>
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/mint" element={<Mint />} />
      </Routes>
    </BrowserRouter>
  )
}

export default Router
